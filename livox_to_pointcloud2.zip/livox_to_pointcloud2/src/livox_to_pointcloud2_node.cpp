#include "livox_to_pointcloud2.hpp"

int main(int argc, char** argv)
{
    ros::init(argc, argv, "livox_to_pointcloud2_node");
    ros::NodeHandle nh;
    LivoxToPointCloud2 node(nh);
    ros::spin();
    return 0;
}

