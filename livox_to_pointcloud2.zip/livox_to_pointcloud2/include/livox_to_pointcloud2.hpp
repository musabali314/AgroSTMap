#ifndef LIVOX_TO_POINTCLOUD2_HPP
#define LIVOX_TO_POINTCLOUD2_HPP

#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <std_msgs/Header.h>
#include "livox_to_pointcloud2/CustomMsg.h"

class LivoxToPointCloud2
{
public:
    LivoxToPointCloud2(ros::NodeHandle& nh);

private:
    void callback(const livox_to_pointcloud2::CustomMsg::ConstPtr& msg);
    ros::Subscriber subscriber_;
    ros::Publisher publisher_;
};

#endif

